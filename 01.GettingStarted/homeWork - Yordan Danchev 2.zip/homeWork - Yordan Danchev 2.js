// Home Work No1 (Problem No1)

let firstNumber = (3);
let secondNumber = (4);
let thirdNumber = (11);
let sum = firstNumber + secondNumber + thirdNumber;

console . log (sum);


let firstNumber = (-2);
let secondNumber = (0);
let thirdNumber = (3);
let sum = firstNumber + secondNumber + thirdNumber;

console . log (sum);


let firstNumber = (5);
let secondNumber = (4);
let thirdNumber = (20);
let sum = firstNumber + secondNumber + thirdNumber;

console . log (sum);


// Home Work No 2 (Problem 2)

let firstName = ' Company name:';
let secondName = ' Telerik';
let thirdName = ' Academy';

console . log (firstName + secondName + thirdName);

let firstInput = ' Company adress: ';
let secondInput = ' 31 Al. Malinov, Sofia ';

console . log (firstInput + secondInput);

let firstInput = ' Phone Number:';
let secondInput = ' +359 888 55 55 555 ';

console . log (firstInput + secondInput);

let firstInput = ' Web site: ';
let secondInput = '	http://telerikacademy.com/ '

console . log (firstInput + secondInput);

let firstInput = ' Manager first name:';
let secondInput = ' Martin';

console . log (firstInput + secondInput);

let firstInput = ' Manager last name: ';
let secondInput = ' Veshev';

console . log (firstInput + secondInput);
